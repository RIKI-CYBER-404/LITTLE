package com.fastaccess.data.dao;

import com.fastaccess.data.dao.model.Commit;

import java.util.ArrayList;

/**
 * Created by Kosh on 12 Feb 2017, 12:10 AM
 */

public class CommitListModel extends ArrayList<Commit> {}
