package com.fastaccess.data.dao;

import com.fastaccess.data.dao.model.User;

import java.util.ArrayList;

/**
 * Created by Kosh on 12 Feb 2017, 1:33 PM
 */

public class UsersListModel extends ArrayList<User> {}
