package com.fastaccess.data.dao;

import java.util.ArrayList;

/**
 * Created by Kosh on 12 Feb 2017, 12:06 AM
 */

public class CommitFileListModel extends ArrayList<CommitFileModel> {}
